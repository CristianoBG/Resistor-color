public class ResistorColorCode {
    private static final String[] COLOR_CODES = {
        "preto", "marrom", "vermelho", "laranja", "amarelo", "verde",
        "azul", "violeta", "cinza", "branco"
    };

    public static String convertToColorCode(String input) {
        String[] parts = input.split(" ");
        if (parts.length != 2) {
            throw new IllegalArgumentException("Formato de entrada incorreto. Use '<valor> <unidade> ohms'.");
        }

        String valuePart = parts[0];
        String unit = parts[1];

        int value;
        int exponent;

        switch (unit) {
            case "ohms":
                value = Integer.parseInt(valuePart);
                exponent = 0;
                break;
            case "k":
                value = (int) (Double.parseDouble(valuePart) * 1000);
                exponent = 1;
                break;
            case "M":
                value = (int) (Double.parseDouble(valuePart) * 1_000_000);
                exponent = 2;
                break;
            default:
                throw new IllegalArgumentException("Unidade não reconhecida: " + unit);
        }

        int firstDigit = value / 10;
        int secondDigit = value % 10;
        int multiplier = exponent;

        StringBuilder colorCode = new StringBuilder();
        colorCode.append(COLOR_CODES[firstDigit / 10]).append(" ");
        colorCode.append(COLOR_CODES[firstDigit % 10]).append(" ");
        colorCode.append(COLOR_CODES[multiplier]).append(" ");
        colorCode.append("dourado");

        return colorCode.toString().trim();
    }

    public static void main(String[] args) {
        System.out.println(convertToColorCode("47 ohms"));
        System.out.println(convertToColorCode("4.7k ohms"));
        System.out.println(convertToColorCode("1M ohms"));
    }
}
